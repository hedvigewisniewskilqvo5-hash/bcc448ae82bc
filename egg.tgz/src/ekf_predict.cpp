// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Run EKF prediction"); }
int main(){
  announce();
  return lionss_run_workload("ekf_predict");
}
