// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scale RoPE frequencies\n", stdout);
  return lionss_run_workload("ropeScale");
}
