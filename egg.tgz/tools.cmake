# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(tallow src/tallow.cpp)
set_property(TARGET tallow PROPERTY CXX_STANDARD 11)
target_link_libraries(tallow lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(denoiseNlm src/denoiseNlm.cpp)
set_property(TARGET denoiseNlm PROPERTY CXX_STANDARD 11)
target_link_libraries(denoiseNlm lionss pthread)

add_executable(driftwood src/driftwood.cpp)
set_property(TARGET driftwood PROPERTY CXX_STANDARD 11)
target_link_libraries(driftwood lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(urdf_validate src/urdf_validate.cpp)
set_property(TARGET urdf_validate PROPERTY CXX_STANDARD 11)
target_link_libraries(urdf_validate lionss pthread)

add_executable(quartzvale src/quartzvale.cpp)
set_property(TARGET quartzvale PROPERTY CXX_STANDARD 11)
target_link_libraries(quartzvale lionss pthread)

add_executable(LorawanAdr src/LorawanAdr.cpp)
set_property(TARGET LorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(LorawanAdr lionss pthread)

add_executable(inputRemap src/inputRemap.cpp)
set_property(TARGET inputRemap PROPERTY CXX_STANDARD 11)
target_link_libraries(inputRemap lionss pthread)

add_executable(ropeScale src/ropeScale.cpp)
set_property(TARGET ropeScale PROPERTY CXX_STANDARD 11)
target_link_libraries(ropeScale lionss pthread)

add_executable(tailwind-purge src/tailwind-purge.cpp)
set_property(TARGET tailwind-purge PROPERTY CXX_STANDARD 11)
target_link_libraries(tailwind-purge lionss pthread)

add_executable(smiles_canon src/smiles_canon.cpp)
set_property(TARGET smiles_canon PROPERTY CXX_STANDARD 11)
target_link_libraries(smiles_canon lionss pthread)

add_executable(shadowCascade4 src/shadowCascade4.cpp)
set_property(TARGET shadowCascade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(shadowCascade4 lionss pthread)

add_executable(star-tracker src/star-tracker.cpp)
set_property(TARGET star-tracker PROPERTY CXX_STANDARD 11)
target_link_libraries(star-tracker lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(VegaSurface src/VegaSurface.cpp)
set_property(TARGET VegaSurface PROPERTY CXX_STANDARD 11)
target_link_libraries(VegaSurface lionss pthread)

add_executable(grafanaPanel src/grafanaPanel.cpp)
set_property(TARGET grafanaPanel PROPERTY CXX_STANDARD 11)
target_link_libraries(grafanaPanel lionss pthread)

add_executable(graphite-owl src/graphite-owl.cpp)
set_property(TARGET graphite-owl PROPERTY CXX_STANDARD 11)
target_link_libraries(graphite-owl lionss pthread)

add_executable(clayfield src/clayfield.cpp)
set_property(TARGET clayfield PROPERTY CXX_STANDARD 11)
target_link_libraries(clayfield lionss pthread)

add_executable(ratelimit src/ratelimit.cpp)
set_property(TARGET ratelimit PROPERTY CXX_STANDARD 11)
target_link_libraries(ratelimit lionss pthread)

add_executable(flintlock src/flintlock.cpp)
set_property(TARGET flintlock PROPERTY CXX_STANDARD 11)
target_link_libraries(flintlock lionss pthread)

add_executable(jitterbuffer src/jitterbuffer.cpp)
set_property(TARGET jitterbuffer PROPERTY CXX_STANDARD 11)
target_link_libraries(jitterbuffer lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(ekf_predict src/ekf_predict.cpp)
set_property(TARGET ekf_predict PROPERTY CXX_STANDARD 11)
target_link_libraries(ekf_predict lionss pthread)

add_executable(opus_encode48k src/opus_encode48k.cpp)
set_property(TARGET opus_encode48k PROPERTY CXX_STANDARD 11)
target_link_libraries(opus_encode48k lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(av1-encode src/av1-encode.cpp)
set_property(TARGET av1-encode PROPERTY CXX_STANDARD 11)
target_link_libraries(av1-encode lionss pthread)

add_executable(ocaml-flambda src/ocaml-flambda.cpp)
set_property(TARGET ocaml-flambda PROPERTY CXX_STANDARD 11)
target_link_libraries(ocaml-flambda lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

add_executable(istio_mtls src/istio_mtls.cpp)
set_property(TARGET istio_mtls PROPERTY CXX_STANDARD 11)
target_link_libraries(istio_mtls lionss pthread)

