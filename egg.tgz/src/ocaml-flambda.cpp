// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Inline across modules\n", stdout);
  return lionss_run_workload("ocaml-flambda");
}
